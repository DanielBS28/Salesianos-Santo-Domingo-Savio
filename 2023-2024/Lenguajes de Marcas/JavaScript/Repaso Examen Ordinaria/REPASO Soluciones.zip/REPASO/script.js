function ejercicio2(){
	var array=["coche","ventana","edificio"]
	var tabla ="<table border='1px'>"
		tabla=tabla+"<tr><th>ELEMENTO</th><th>LONGITUD</th></tr>"
	for(var i=0;i<array.length;i++){
		
		tabla=tabla+"<tr><td>"+array[i]+"</td><td>"+array[i].length+"</td></tr>"
	}
	tabla=tabla+"</table>"
	document.getElementById("ejercicio2").innerHTML=tabla;
}
function comprobarNombre(nombre){
	cadenaRegular=/^[a-zA-Z]+$/

	if(nombre.match(cadenaRegular))
		 return true;
	else 
		return false;
}
function comprobarEmail(correo){
	var cadenaRegular=/^[a-zA-Z0-9]+@[a-zA-Z]+\.[a-zA-Z]$/

	if (cadenaRegular.test(correo))
		 return true;
	else 
		return false;
}
function comprobarContrasena(password){
	var cadenaRegular=/^[a-z]+[A-Z]+[0-9]+$/
	if(password.match(cadenaRegular)&&(password.length>=6))
		 return true;
	else 
		return false;
}
function formulario(){
	var nombre=document.getElementById("nombre").value;
	var email=document.getElementById("email").value;
	var comentarios=document.getElementById("comentarios").value;
	var password=document.getElementById("password").value;

	if((nombre.length>0)&&(email.length>0)&&(comentarios.length>0)&&(comentarios.length<=50)){
		/*if(comprobarNombre(nombre))
			alert("nombre correcto")*/
		if(comprobarEmail(email))
			alert("correo correcto")
		else
			alert("correo incorrecto")

		if(comprobarContrasena(password))
			alert("contraseña correcto")
		else
			alert("contraseña incorrecta")
		document.getElementById("resultado").innerHTML=nombre+" "+email+" "+comentarios+" "+password;
	}else 
		alert("datos invalidos")

}
function carga(){
	ejercicio2();
	document.getElementById("botonFomulario").addEventListener("click",formulario);
}
window.addEventListener("DOMContentLoaded", carga);

/**
 * 
 */
/**
 * 
 */
module Proyecto_Mecanografia_Isaac_Beltran {
	requires java.desktop;
}
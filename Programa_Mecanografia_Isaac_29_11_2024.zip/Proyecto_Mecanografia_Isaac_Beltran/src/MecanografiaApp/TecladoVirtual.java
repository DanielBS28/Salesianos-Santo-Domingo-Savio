package MecanografiaApp;

import javax.swing.*;
import java.awt.*;

public class TecladoVirtual extends JPanel {
    private JButton[] teclas;

    public TecladoVirtual() {
        setLayout(new GridLayout(4, 10));
        String letras = "QWERTYUIOPASDFGHJKLZXCVBNM";
        teclas = new JButton[letras.length()];

        for (int i = 0; i < letras.length(); i++) {
            teclas[i] = new JButton(String.valueOf(letras.charAt(i)));
            teclas[i].setFocusable(false);
            add(teclas[i]);
        }
    }

    public void resaltarTecla(char letra, boolean correcta) {
        for (JButton tecla : teclas) {
            if (tecla.getText().equalsIgnoreCase(String.valueOf(letra))) {
                tecla.setBackground(correcta ? Color.GREEN : Color.RED);
                break;
            }
        }
    }

    public void restablecerTecla(char letra) {
        for (JButton tecla : teclas) {
            if (tecla.getText().equalsIgnoreCase(String.valueOf(letra))) {
                tecla.setBackground(null); // Restablecer al color predeterminado
                break;
            }
        }
    }
}

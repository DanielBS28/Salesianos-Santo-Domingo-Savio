package MecanografiaApp;

import java.io.*;
import java.util.*;

public class Utilidades {
    private static final String RUTA_ARCHIVO = ".\\Archivos\\usuarios.txt";
    private static final String USUARIO_ADMIN = "admin";
    private static final String CONTRASEÑA_ADMIN = "admin";
    private static final int MAX_USUARIOS = 5;

    // Cargar usuarios desde el archivo
    public static List<Usuario> cargarUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(RUTA_ARCHIVO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    usuarios.add(new Usuario(partes[0], partes[1]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar usuarios: " + e.getMessage());
        }

        // Asegurar que el administrador siempre está presente
        boolean adminExiste = usuarios.stream().anyMatch(u -> u.getNombre().equals(USUARIO_ADMIN));
        if (!adminExiste) {
            usuarios.add(new Usuario(USUARIO_ADMIN, CONTRASEÑA_ADMIN));
            guardarUsuarios(usuarios);
        }

        return usuarios;
    }

    // Guardar todos los usuarios en el archivo
    public static void guardarUsuarios(List<Usuario> usuarios) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(RUTA_ARCHIVO))) {
            for (Usuario u : usuarios) {
                pw.println(u.getNombre() + "," + u.getContraseña());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar usuarios: " + e.getMessage());
        }
    }

    // Guardar un solo usuario nuevo
    public static boolean guardarUsuario(Usuario usuario) {
        List<Usuario> usuarios = cargarUsuarios();

        // Verificar si ya hay 5 usuarios (excluyendo al admin)
        long totalUsuarios = usuarios.stream().filter(u -> !u.getNombre().equals(USUARIO_ADMIN)).count();
        if (totalUsuarios >= MAX_USUARIOS) {
            return false;
        }

        // Agregar el nuevo usuario si no excede el límite
        usuarios.add(usuario);
        guardarUsuarios(usuarios);
        return true;
    }

    // Eliminar un usuario (excepto el admin)
    public static boolean eliminarUsuario(String nombre) {
        if (nombre.equals(USUARIO_ADMIN)) {
            return false;  // No se puede eliminar el admin
        }

        List<Usuario> usuarios = cargarUsuarios();
        usuarios.removeIf(u -> u.getNombre().equals(nombre));
        guardarUsuarios(usuarios);
        return true;
    }
}

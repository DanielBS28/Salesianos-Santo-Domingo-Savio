package MecanografiaApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Timer;
import java.util.TimerTask;
import java.util.function.Consumer;

public class Practica extends JPanel {
    private JTextArea areaTexto, areaEscribir;
    private JLabel lblContador, lblErrores;
    private Timer timer;
    private int tiempoRestante;
    private int errores;
    private int maxErrores;
    private TecladoVirtual tecladoVirtual;
    private JButton btnComprobar;

    public Practica(String texto, int tiempoLimite, int maxErrores, Consumer<Boolean> onFinish) {
        setLayout(new BorderLayout());
        this.maxErrores = maxErrores;
        this.tiempoRestante = tiempoLimite;

        // Título
        JLabel lblTitulo = new JLabel("Práctica de Mecanografía", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        add(lblTitulo, BorderLayout.NORTH);

        // Panel central con texto y área de escritura
        JPanel panelCentral = new JPanel(new GridLayout(2, 1));
        areaTexto = new JTextArea(texto);
        areaTexto.setEditable(false);
        areaTexto.setLineWrap(true);
        areaTexto.setWrapStyleWord(true);
        panelCentral.add(new JScrollPane(areaTexto));

        areaEscribir = new JTextArea();
        panelCentral.add(new JScrollPane(areaEscribir));
        add(panelCentral, BorderLayout.CENTER);

        // Teclado virtual en la parte inferior
        tecladoVirtual = new TecladoVirtual();
        add(tecladoVirtual, BorderLayout.SOUTH);

        // Panel inferior con contador de tiempo, errores
        JPanel panelInferior = new JPanel(new GridLayout(1, 2));
        lblContador = new JLabel("Tiempo restante: " + tiempoLimite + " segundos", SwingConstants.CENTER);
        panelInferior.add(lblContador);

        lblErrores = new JLabel("Errores: 0 / " + maxErrores, SwingConstants.CENTER);
        panelInferior.add(lblErrores);

        add(panelInferior, BorderLayout.NORTH);

        // Crear el botón "Comprobar"
        JPanel panelLateral = new JPanel();
        panelLateral.setLayout(new BorderLayout());
        btnComprobar = new JButton("Comprobar");
        btnComprobar.addActionListener(e -> comprobarTexto(onFinish));
        panelLateral.add(btnComprobar, BorderLayout.CENTER);

        // Añadir el panel lateral a la parte derecha
        add(panelLateral, BorderLayout.EAST);

        // Iniciar el temporizador
        iniciarTemporizador(onFinish);

        // Capturar eventos de teclado
        areaEscribir.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                char teclaPresionada = e.getKeyChar();
                // Solo procesar teclas alfabéticas (a-z) y no alfabéticas serán ignoradas
                if (esTeclaValida(teclaPresionada)) {
                    verificarTeclaCorrecta(teclaPresionada);
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                char teclaPresionada = e.getKeyChar();
                if (esTeclaValida(teclaPresionada)) {
                    tecladoVirtual.restablecerTecla(teclaPresionada);
                }
            }
        });
    }

    // Iniciar el temporizador para contar el tiempo
    private void iniciarTemporizador(Consumer<Boolean> onFinish) {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                tiempoRestante--;
                lblContador.setText("Tiempo restante: " + tiempoRestante + " segundos");
                if (tiempoRestante <= 0) {
                    timer.cancel();
                    comprobarTexto(onFinish);  // Llamamos a comprobarTexto automáticamente cuando el tiempo se acaba
                }
            }
        }, 1000, 1000);
    }

 // Verifica si la tecla es válida (alfabéticas y espacio)
    private boolean esTeclaValida(char tecla) {
        return (tecla >= 'a' && tecla <= 'z') || (tecla >= 'A' && tecla <= 'Z') || tecla == ' ';
    }


 // Verifica si la tecla presionada es la correcta según el texto y marca error si es necesario
    private void verificarTeclaCorrecta(char tecla) {
    	String textoOriginal = areaTexto.getText();  // El texto original sin recortar
    	String textoEscrito = areaEscribir.getText();  // El texto escrito por el usuario, también sin recortar

       // System.out.println("Texto Original: '" + textoOriginal + "'");
        //System.out.println("Texto Escrito: '" + textoEscrito + "'");

        // Verifica si la longitud del texto escrito es menor o igual a la longitud del texto original
        if (textoEscrito.length() <= textoOriginal.length()) {
            char siguienteCaracterEsperado = textoOriginal.charAt(textoEscrito.length());

         //   System.out.println("Carácter Esperado: " + siguienteCaracterEsperado);
           // System.out.println("Carácter Presionado: " + tecla);

            // Si el carácter esperado coincide con la tecla presionada
            if (siguienteCaracterEsperado == tecla) {
                tecladoVirtual.resaltarTecla(tecla, true);  // Resaltar en verde (correcto)
            } else {
                tecladoVirtual.resaltarTecla(tecla, false);  // Resaltar en rojo (incorrecto)
                aumentarError();  // Aumentar contador de errores
            }
        }
    }


    // Aumenta el contador de errores y verifica si se superaron los errores permitidos
    private void aumentarError() {
        errores++;
        lblErrores.setText("Errores: " + errores + " / " + maxErrores);

        if (errores > maxErrores) {
            timer.cancel();
            mostrarGameOver();
        }
    }

    // Muestra el mensaje de "Game Over" y da la opción de volver a empezar o salir
    private void mostrarGameOver() {
        int opcion = JOptionPane.showOptionDialog(this,
                "¡Game Over! Has superado el número de errores permitidos.",
                "Juego Terminado",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, new Object[]{"Volver a empezar", "Salir"}, "Volver a empezar");

        if (opcion == 0) {
            reiniciarJuego();
        } else {
            System.exit(0);
        }
    }

    // Verifica el texto final escrito por el usuario
    private void comprobarTexto(Consumer<Boolean> onFinish) {
    	String textoOriginal = areaTexto.getText();  // El texto original sin recortar
    	String textoEscrito = areaEscribir.getText();  // El texto escrito por el usuario, también sin recortar

        if (textoOriginal.equals(textoEscrito)) {
            // Si es correcto, se muestra la pantalla de logro sin mensaje
            mostrarLogro();
            onFinish.accept(true);
        } else {
            onFinish.accept(false);
            JOptionPane.showMessageDialog(this, "¡Tienes errores! No completaste correctamente la lección.", "Errores", JOptionPane.WARNING_MESSAGE);
        }
    }

    // Método para mostrar el certificado de logro
    private void mostrarLogro() {
    	Completado logroPanel = new Completado();  // Crear el panel de logro
        getParent().add(logroPanel, "Logro"); // Añadirlo al layout
        CardLayout cl = (CardLayout) getParent().getLayout();
        cl.show(getParent(), "Logro");
    }

    // Reinicia el juego, mostrando nuevamente el panel de selección de nivel
    private void reiniciarJuego() {
        areaEscribir.setText("");
        errores = 0;
        lblErrores.setText("Errores: 0 / " + maxErrores);
        tiempoRestante = 240; // O el tiempo inicial de la lección
        lblContador.setText("Tiempo restante: " + tiempoRestante + " segundos");
        iniciarTemporizador(onFinish -> {});
    }
}

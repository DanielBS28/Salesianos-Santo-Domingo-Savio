package MecanografiaApp;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class NivelPractica extends JPanel {
    public NivelPractica(java.util.function.Consumer<String> onLevelSelected) {
        setLayout(new GridLayout(3, 1));

        JLabel lblTitulo = new JLabel("Selecciona un nivel:", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        add(lblTitulo);

        JButton btnFacil = new JButton("Nivel Fácil");
        btnFacil.addActionListener(e -> onLevelSelected.accept("facil"));
        add(btnFacil);

        JButton btnDificil = new JButton("Nivel Difícil");
        btnDificil.addActionListener(e -> onLevelSelected.accept("dificil"));
        add(btnDificil);
    }

    public static String cargarTexto(String nivel) {
        String ruta = ".\\Archivos\\leccion.txt";
        StringBuilder texto = new StringBuilder();
        boolean leer = false;

        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().equalsIgnoreCase("#FACIL") && nivel.equals("facil")) {
                    leer = true;  // Comienza a leer la sección fácil
                    continue;
                } else if (linea.trim().equalsIgnoreCase("#DIFICIL") && nivel.equals("dificil")) {
                    leer = true;  // Comienza a leer la sección difícil
                    continue;
                } else if (linea.startsWith("#") && !linea.trim().equalsIgnoreCase("#" + nivel.toUpperCase())) {
                    leer = false;  // Deja de leer cuando encuentra otra etiqueta
                }

                if (leer) {
                    texto.append(linea).append("\n");  // Acumula las líneas de la sección seleccionada
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar el texto: " + e.getMessage());
            return "";
        }

        return texto.toString().trim();
    }
}

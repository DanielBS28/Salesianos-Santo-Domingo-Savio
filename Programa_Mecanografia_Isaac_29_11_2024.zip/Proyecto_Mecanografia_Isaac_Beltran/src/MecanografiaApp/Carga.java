spackage MecanografiaApp;

import javax.swing.*;
import java.awt.*;

public class Carga extends JPanel {
    private JProgressBar progressBar;
    private Timer timer;
    private int progress;

    public Carga(Runnable onFinish) {
        setLayout(new BorderLayout());

        // Cargar y escalar la imagen de fondo a las dimensiones de la pantalla completa
        ImageIcon imagenFondo = new ImageIcon(".\\Imagenes\\Fondo_app.png");
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();  // Obtener dimensiones de la pantalla
        Image imagenEscalada = imagenFondo.getImage().getScaledInstance(screenSize.width, screenSize.height, Image.SCALE_SMOOTH);
        JLabel labelFondo = new JLabel(new ImageIcon(imagenEscalada));
        labelFondo.setLayout(new BorderLayout());
        add(labelFondo, BorderLayout.CENTER);

        // Crear la barra de progreso
        progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(screenSize.width, 30));  // Barra de progreso a lo ancho de la pantalla
        progressBar.setStringPainted(true);
        labelFondo.add(progressBar, BorderLayout.SOUTH);  // Posicionar la barra en la parte inferior de la imagen

        // Temporizador para actualizar la barra de progreso
        timer = new Timer(60, e -> {
            progress++;
            progressBar.setValue(progress);
            if (progress >= 100) {
                timer.stop();
                onFinish.run();  // Llamar al método proporcionado cuando la carga finaliza
            }
        });
        timer.start();
    }
}

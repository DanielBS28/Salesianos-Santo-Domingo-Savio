package MecanografiaApp;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Main extends JFrame {
	private JPanel Login, Menu, CargaInicio, Administrador;
	private JTextField txtUsuario;
	private JPasswordField txtPassword;
	private String usuarioActual;

	public Main() {
		// Icono de la app
		setIconImage(Toolkit.getDefaultToolkit().getImage(".\\Imagenes\\logo.png"));

		// Título de la app
		setTitle("Proyecto Mecanografía");

		// Ponerlo en pantalla completa
		setExtendedState(JFrame.MAXIMIZED_BOTH);

		// No cerrar automaticamente
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		// crear el card Layout
		getContentPane().setLayout(new CardLayout());

		// Paneles principales
		CargaInicio = new Carga(() -> mostrarPanel("Login"));
		Login = crearPanelLogin();
		Menu = crearPanelMenu();
		Administrador = crearPanelAdmin();

		// Añadir los paneles importantes al card Layout
		// ESTRUCTURA-> "nombre_del_panel_principal, clave para referirsele"
		getContentPane().add(CargaInicio, "Carga");
		getContentPane().add(Login, "Login");
		getContentPane().add(Menu, "Menu");
		getContentPane().add(Administrador, "Admin");

		// Mostrar el panel de carga
		mostrarPanel("Carga");

		// Confirmación de cierre de la app
		// #########################################################
		addWindowListener(new java.awt.event.WindowAdapter() {

			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				int confirm = JOptionPane.showConfirmDialog(null, "¿Vas a salir de la aplicación?", "Salida de la app",
						JOptionPane.YES_NO_OPTION);
				if (confirm == JOptionPane.YES_OPTION) {
					// salir si da "si"
					System.exit(0);
				}
			}
		});
	}
	// ###############################################################################################

	// ############################### CRAECIÓN DEL LOGIN ###############################
	private JPanel crearPanelLogin() {
		// panel principal
		JPanel panel = new JPanel(new BorderLayout());

		// Fondo con imagen
		JLabel fondo = new JLabel(new ImageIcon(".\\Imagenes\\Fondo_Login.jpg"));
		// permitir el centrado de los objetos
		fondo.setLayout(new GridBagLayout());
		// añadir
		panel.add(fondo, BorderLayout.CENTER);

		// Panel interno para organizar los componentes
		JPanel panelCentro = new JPanel();
		// Transparente para mostrar el fondo
		panelCentro.setOpaque(false);
		panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));

		// tecto de usuario
		JLabel lblUsuario = new JLabel("Usuario:");
		lblUsuario.setFont(new Font("Arial", Font.BOLD, 18));
		lblUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblUsuario.setBackground(Color.WHITE);
		lblUsuario.setOpaque(true);
		panelCentro.add(lblUsuario);

		// campor para rellenar: Usuario
		txtUsuario = new JTextField(15);
		txtUsuario.setMaximumSize(new Dimension(200, 30));
		panelCentro.add(Box.createRigidArea(new Dimension(0, 10)));
		panelCentro.add(txtUsuario);

		// texto de contraseña
		JLabel lblPassword = new JLabel("Contraseña:");
		lblPassword.setFont(new Font("Arial", Font.BOLD, 18));
		lblPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
		panelCentro.add(Box.createRigidArea(new Dimension(0, 10)));
		lblPassword.setBackground(Color.WHITE);
		lblPassword.setOpaque(true);
		panelCentro.add(lblPassword);

		// campo para rellenar: contraseña
		txtPassword = new JPasswordField(15);
		txtPassword.setMaximumSize(new Dimension(200, 30));
		panelCentro.add(Box.createRigidArea(new Dimension(0, 10)));
		panelCentro.add(txtPassword);

		// boton para iniciar sesion
		JButton btnLogin = new JButton("Ingresar");
		btnLogin.setFont(new Font("Arial", Font.BOLD, 16));
		btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);

		btnLogin.addActionListener(e -> inicioSesion()); // cuando es pulsado iniciar la acción del método
															// "inicioSesion"
		panelCentro.add(Box.createRigidArea(new Dimension(0, 10)));
		panelCentro.add(btnLogin);

		// Agregar componentes al fondo
		fondo.add(panelCentro);
		return panel;
	}

	// MÉTODO PARA EL INICIO DE SESIÓN 
	private void inicioSesion() {

		String usuario = txtUsuario.getText().trim();
		String password = new String(txtPassword.getPassword()).trim();

		// VALIDACIÓN PARA EL ADIMISTRADOR
		if ("admin".equals(usuario) && "admin".equals(password)) {
			usuarioActual = usuario;
			mostrarPanel("Admin"); // Accede al panel de administración
			return;
		}

		// VALIDACIÓN PARA LOS USUARIOS
		List<Usuario> usuarios = Utilidades.cargarUsuarios();

		// recorre los usuarios y si coinciden los nombres de usuarios con la
		// contraseña, permite el inicio de sesión

		for (Usuario u : usuarios) {
			if (u.getNombre().equals(usuario) && u.getContraseña().equals(password)) {
				usuarioActual = usuario;
				mostrarPanel("Menu"); // Accede al menú del usuario
				return;
			}
		}

		// si no está el usuario, salta el error de credenciales incorrectas
		JOptionPane.showMessageDialog(this, "Ups... Algo ha ido mal\n"
				+ "Compureba las credenciales y vuelve a intentarlo", "Fallo al iniciar sesión", JOptionPane.ERROR_MESSAGE);
	}

	// MÉTODO PARA EL MENÚ DE USUARIO
	private JPanel crearPanelMenu() {

		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(Color.GREEN);

		// Crea la barra de menú superior y muestra la imagen
		JMenuBar menuBar = new JMenuBar();
		JMenu menuArchivo = new JMenu("Menú");
		JMenuItem menuAyuda = new JMenuItem("Ayuda");
		menuAyuda.addActionListener(e -> mostrarPanelConImagen()); //muestra la imagen de guia cuando se va a ayuda
		//añade
		menuArchivo.add(menuAyuda);
		menuBar.add(menuArchivo);
		setJMenuBar(menuBar);

		
		//texto
		JLabel lblMenu = new JLabel("Seleccione el nivel de práctica", SwingConstants.CENTER);
		lblMenu.setFont(new Font("Arial", Font.BOLD, 20));
		panel.add(lblMenu, BorderLayout.NORTH);

		//crea un panel para meter los botones dentro y que ocupe casi toda la pantalla
		JPanel panelBotones = new JPanel(new GridLayout(3, 1, 10, 10));
		JButton btnFacil = new JButton("Nivel Fácil");
		JButton btnDificil = new JButton("Nivel Difícil");
		JButton btnVolver = new JButton("Volver al Login");

		
		//dependiendo el boton se realiza una acción u otra
		btnFacil.addActionListener(e -> cargarLeccion("facil"));
		btnDificil.addActionListener(e -> cargarLeccion("dificil"));
		btnVolver.addActionListener(e -> mostrarPanel("Login"));

		//añade
		panelBotones.add(btnFacil);
		panelBotones.add(btnDificil);
		panelBotones.add(btnVolver);

		panel.add(panelBotones, BorderLayout.CENTER);
		return panel;
	}

	//MÉTODO PARA MOSTRAR LA IMAGEN DE GUIA
	private void mostrarPanelConImagen() {
		
		// Cargar la imagen de guia
		ImageIcon imagen = new ImageIcon(".\\imagenes\\ayuda_dedos_mecano.png");
		JLabel imagenLabel = new JLabel(imagen);

		// Panel para mostrar la imagen (en un principo texto, sino no)
		JPanel panelImagenConTexto = new JPanel();
		panelImagenConTexto.setLayout(null);
		panelImagenConTexto.setPreferredSize(new Dimension(imagen.getIconWidth(), imagen.getIconHeight()));

		imagenLabel.setBounds(0, 0, imagen.getIconWidth(), imagen.getIconHeight());
		panelImagenConTexto.add(imagenLabel);

		// Mostrar el panel en un jopctionpane
		JOptionPane.showMessageDialog(this, panelImagenConTexto, "Ayuda", JOptionPane.INFORMATION_MESSAGE);
	}

	
	
	// MÉTODO PARA CARGAR EL NIVEL
	private void cargarLeccion(String nivel) {
		
		//carga del texto de la práctica
		String texto = NivelPractica.cargarTexto(nivel);
		//crea el tiempo de la practica (240 pra el facil y 180 para el dificil)
		int tiempo = nivel.equals("facil") ? 240 : 180;

		//
		JPanel practicaPanel = new Practica(texto, tiempo, 5, completado -> {
			//si se completa que salga el panel de Completado
			if (completado) {
				mostrarPanel("Completado"); // Mostrar el panel de logro si la lección es completada
			} else {
				//Si no se completa mostrar el mensaje de que no se ha completado
				JOptionPane.showMessageDialog(this, "Vaya...\n"
						+ "Parece que no has tenido el tiempo suficiente", "FIN",
						JOptionPane.ERROR_MESSAGE);
				mostrarPanel("Menu");
			}
		});

		getContentPane().add(practicaPanel, "Practica");
		mostrarPanel("Practica");
	}

	// Método para crear el panel de administración
	private JPanel crearPanelAdmin() {
		JPanel panel = new JPanel(new BorderLayout());

		// Fondo con imagen
		JLabel fondo = new JLabel(new ImageIcon(".\\Imagenes\\Fondo_Admin.jpg"));
		fondo.setLayout(new BorderLayout());
		panel.add(fondo, BorderLayout.CENTER);

		// Título
		JLabel lblAdmin = new JLabel("Administrar Usuarios", SwingConstants.CENTER);
		lblAdmin.setFont(new Font("Arial", Font.BOLD, 20));
		lblAdmin.setBackground(Color.YELLOW);
		lblAdmin.setOpaque(true);
		fondo.add(lblAdmin, BorderLayout.NORTH);

		// Panel izquierdo: Formulario para agregar usuarios
		JPanel panelCampos = new JPanel(new GridLayout(3, 2, 10, 10)); // 3 filas, 2 columnas
		panelCampos.setOpaque(false); // Transparente para el fondo
		panelCampos.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Espaciado interno

		JLabel lblNuevoUsuario = new JLabel("Nuevo Usuario:");
		lblNuevoUsuario.setFont(new Font("Arial", Font.PLAIN, 16));
		JTextField txtNuevoUsuario = new JTextField(15);

		JLabel lblNuevoPassword = new JLabel("Contraseña:");
		lblNuevoPassword.setFont(new Font("Arial", Font.PLAIN, 16));
		JPasswordField txtNuevoPassword = new JPasswordField(15);

		panelCampos.add(lblNuevoUsuario);
		panelCampos.add(txtNuevoUsuario);
		panelCampos.add(lblNuevoPassword);
		panelCampos.add(txtNuevoPassword);

		fondo.add(panelCampos, BorderLayout.WEST);

		// Panel derecho: Lista de usuarios
		JPanel panelUsuarios = new JPanel(new BorderLayout());
		panelUsuarios.setOpaque(false);

		JLabel lblUsuarios = new JLabel("Usuarios:", SwingConstants.CENTER);
		lblUsuarios.setFont(new Font("Arial", Font.BOLD, 16));
		panelUsuarios.add(lblUsuarios, BorderLayout.NORTH);

		DefaultListModel<String> modeloLista = new DefaultListModel<>();
		JList<String> listaUsuarios = new JList<>(modeloLista);
		Utilidades.cargarUsuarios().forEach(u -> modeloLista.addElement(u.getNombre()));
		panelUsuarios.add(new JScrollPane(listaUsuarios), BorderLayout.CENTER);

		fondo.add(panelUsuarios, BorderLayout.EAST);

		// Panel inferior: Botones
		JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Botones alineados al centro
		panelBotones.setOpaque(false);

		JButton btnAgregar = new JButton("Agregar Usuario");
		JButton btnEliminar = new JButton("Eliminar Usuario");
		JButton btnVolverLogin = new JButton("Volver al Login");

		panelBotones.add(btnAgregar);
		panelBotones.add(btnEliminar);
		panelBotones.add(btnVolverLogin);

		fondo.add(panelBotones, BorderLayout.SOUTH);

		// Funcionalidad de los botones
		btnAgregar.addActionListener(e -> {
			String nombre = txtNuevoUsuario.getText().trim();
			String pass = new String(txtNuevoPassword.getPassword()).trim();

			if (!nombre.isEmpty() && !pass.isEmpty()) {
				if (Utilidades.guardarUsuario(new Usuario(nombre, pass))) {
					modeloLista.addElement(nombre);
					txtNuevoUsuario.setText("");
					txtNuevoPassword.setText("");
					JOptionPane.showMessageDialog(this, "Usuario agregado con éxito.");
				} else {
					JOptionPane.showMessageDialog(this, "No se pueden agregar más de 5 usuarios.", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			} else {
				JOptionPane.showMessageDialog(this, "Debe completar ambos campos.", "Error", JOptionPane.ERROR_MESSAGE);
			}
		});

		btnEliminar.addActionListener(e -> {
			String usuarioSeleccionado = listaUsuarios.getSelectedValue();
			if (usuarioSeleccionado != null) {
				if (!usuarioSeleccionado.equals("a")) { // No eliminar al administrador
					if (Utilidades.eliminarUsuario(usuarioSeleccionado)) {
						modeloLista.removeElement(usuarioSeleccionado);
						JOptionPane.showMessageDialog(this, "Usuario eliminado con éxito.");
					}
				} else {
					JOptionPane.showMessageDialog(this, "No se puede eliminar el administrador.", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			} else {
				JOptionPane.showMessageDialog(this, "Seleccione un usuario para eliminar.", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
		});

		btnVolverLogin.addActionListener(e -> mostrarPanel("Login"));

		return panel;
	}

	private void mostrarPanel(String panel) {
		CardLayout cl = (CardLayout) getContentPane().getLayout();
		cl.show(getContentPane(), panel);
	}

	// Clase auxiliar para crear paneles con fondo
	static class PanelConFondo extends JPanel {
		private Image imagenFondo;

		public PanelConFondo(String rutaImagen) {
			try {
				this.imagenFondo = new ImageIcon(rutaImagen).getImage();
			} catch (Exception e) {
				e.printStackTrace();
			}
			setLayout(new BorderLayout());
		}

		public void setImagen(String ruta) {
			this.imagenFondo = new ImageIcon(ruta).getImage();
			repaint();
		}

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			if (imagenFondo != null) {
				g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), this);
			}
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new Main().setVisible(true));
	}
}

package MecanografiaApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Completado extends JPanel {

    public Completado() {
        GridBagLayout gridBagLayout = new GridBagLayout();
        gridBagLayout.columnWidths = new int[]{450, 0};
        gridBagLayout.rowHeights = new int[]{50, 50, 50, 50, 50, 50, 0};
        gridBagLayout.columnWeights = new double[]{0.0, Double.MIN_VALUE};
        gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
        setLayout(gridBagLayout);
        
                // Título del logro
                JLabel lblCertificado = new JLabel("¡Felicidades! Has completado la lección correctamente!!!");
                lblCertificado.setFont(new Font("Arial", Font.BOLD, 15));
                GridBagConstraints gbc_lblCertificado = new GridBagConstraints();
                gbc_lblCertificado.fill = GridBagConstraints.BOTH;
                gbc_lblCertificado.insets = new Insets(0, 0, 5, 0);
                gbc_lblCertificado.gridx = 0;
                gbc_lblCertificado.gridy = 0;
                add(lblCertificado, gbc_lblCertificado);
        
        JLabel lblNewLabel = new JLabel("· En la versión 2.0 de la aplicación, se añadirán las siguientes funciones:");
        GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
        gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
        gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
        gbc_lblNewLabel.gridx = 0;
        gbc_lblNewLabel.gridy = 1;
        add(lblNewLabel, gbc_lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("- Función para saber la puntuación del usuario dependiendo de su habilidad al realizar las pácticas");
        GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
        gbc_lblNewLabel_1.fill = GridBagConstraints.BOTH;
        gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 0);
        gbc_lblNewLabel_1.gridx = 0;
        gbc_lblNewLabel_1.gridy = 2;
        add(lblNewLabel_1, gbc_lblNewLabel_1);
        
        JLabel lblNewLabel_3 = new JLabel("- Función para enviar un correo electrónico al usuario en el caso de que mejore su puntuación");
        GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
        gbc_lblNewLabel_3.fill = GridBagConstraints.BOTH;
        gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 0);
        gbc_lblNewLabel_3.gridx = 0;
        gbc_lblNewLabel_3.gridy = 3;
        add(lblNewLabel_3, gbc_lblNewLabel_3);
        
                // Crear panel para los botones
                JPanel panelBotones = new JPanel();
                JButton btnVolver = new JButton("Volver al Menú");
                btnVolver.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Volver al panel de inicio (Menú)
                        CardLayout cl = (CardLayout) getParent().getLayout();
                        cl.show(getParent(), "Menu");
                    }
                });
                
                JButton btnSalir = new JButton("Salir");
                btnSalir.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Salir de la aplicación
                        System.exit(0);
                    }
                });
                
                        panelBotones.add(btnVolver);
                        panelBotones.add(btnSalir);
                        GridBagConstraints gbc_panelBotones = new GridBagConstraints();
                        gbc_panelBotones.fill = GridBagConstraints.BOTH;
                        gbc_panelBotones.insets = new Insets(0, 0, 5, 0);
                        gbc_panelBotones.gridx = 0;
                        gbc_panelBotones.gridy = 4;
                        add(panelBotones, gbc_panelBotones);
        
        JLabel label = new JLabel("");
        GridBagConstraints gbc_label = new GridBagConstraints();
        gbc_label.fill = GridBagConstraints.BOTH;
        gbc_label.gridx = 0;
        gbc_label.gridy = 5;
        add(label, gbc_label);
    }
}

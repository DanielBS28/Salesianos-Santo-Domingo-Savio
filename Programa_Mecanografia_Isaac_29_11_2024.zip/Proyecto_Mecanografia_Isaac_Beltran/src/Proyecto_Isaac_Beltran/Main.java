package Proyecto_Isaac_Beltran;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class Main extends JFrame {
    private JPanel panelCarga, panelLogin, panelMenu, panelLeccion, panelAdmin;
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private TecladoVirtual teclado;

    /** Constructor principal de la clase Main */
    public Main() {
        // Configuración inicial de la ventana principal
        setIconImage(Toolkit.getDefaultToolkit().getImage(".\\imagenes\\logo.png"));
        setTitle("Mecanografía");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new CardLayout());

        // Creación de los paneles
        panelCarga = crearPanelCarga();
        panelLogin = crearPanelLogin();
        panelMenu = crearPanelMenu();
        panelLeccion = crearPanelLeccion();
        panelAdmin = crearPanelAdmin();
        
        // Añadir los paneles a la ventana
        getContentPane().add(panelCarga, "Carga");
        getContentPane().add(panelLogin, "Login");
        getContentPane().add(panelMenu, "Menu");
        getContentPane().add(panelLeccion, "Leccion");
        getContentPane().add(panelAdmin, "Admin");

        // Panel de selección de lección
        JPanel panelEleccionLeccion = new JPanel();
        getContentPane().add(panelEleccionLeccion, "name_8376971723500");
        panelEleccionLeccion.setLayout(null);
        JButton btnFacil = new JButton("FÁCIL");
        btnFacil.setBounds(335, 188, 140, 38);
        panelEleccionLeccion.add(btnFacil);
        JButton btnDificil = new JButton("DIFÍCIL");
        btnDificil.setBounds(335, 350, 140, 38);
        panelEleccionLeccion.add(btnDificil);

        // Mostrar el panel de carga
        mostrarPanel("Carga");
        iniciarCarga();
    }

    /** Método para crear el panel de carga con una imagen */
    private JPanel crearPanelCarga() {
        JPanel panelCargador = new JPanel();
        panelCargador.setLayout(null);

        // Cargar imagen de fondo
        ImageIcon imagenFondo = new ImageIcon(".\\imagenes\\fondo_carga.jpg");

        // Verificación de carga de la imagen
        if (imagenFondo.getIconWidth() == -1) {
            JOptionPane.showMessageDialog(this, "No se pudo cargar la imagen en la ruta especificada.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        JLabel labelFondo = new JLabel(imagenFondo);
        labelFondo.setBounds(0, 0, 800, 600);
        panelCargador.add(labelFondo);

        // Barra de progreso
        JProgressBar progressBar = new JProgressBar();
        progressBar.setBounds(150, 500, 500, 20);
        progressBar.setIndeterminate(true);
        labelFondo.add(progressBar);

        return panelCargador;
    }

    /** Método para crear el panel de inicio de sesión */
    private JPanel crearPanelLogin() {
        JPanel panelInicioSesion = new JPanel();
        panelInicioSesion.setLayout(null);

        // Crear etiquetas y campos de texto para usuario y contraseña
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(150, 50, 100, 25);
        panelInicioSesion.add(lblUsuario);
        txtUsuario = new JTextField();
        txtUsuario.setBounds(250, 50, 200, 25);
        panelInicioSesion.add(txtUsuario);

        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setBounds(150, 100, 100, 25);
        panelInicioSesion.add(lblPassword);
        txtPassword = new JPasswordField();
        txtPassword.setBounds(250, 100, 200, 25);
        panelInicioSesion.add(txtPassword);

        // Botón para iniciar sesión
        JButton btnIngresar = new JButton("Ingresar");
        btnIngresar.setBounds(250, 150, 100, 30);
        btnIngresar.addActionListener(e -> validarCredenciales());
        panelInicioSesion.add(btnIngresar);

        return panelInicioSesion;
    }

    /** Método para crear el panel del menú principal */
    private JPanel crearPanelMenu() {
        JPanel panelUsuario = new JPanel();

        // Barra de menú superior
        JMenuBar menuBar = new JMenuBar();
        JMenu menuArchivo = new JMenu("Menú");
        JMenuItem menuAyuda = new JMenuItem("Ayuda");
        menuAyuda.addActionListener(e -> mostrarPanelConImagen());
        menuArchivo.add(menuAyuda);
        menuBar.add(menuArchivo);
        setJMenuBar(menuBar);

        // Botón para iniciar lección
        JButton btnLeccion = new JButton("Iniciar Lección");
        btnLeccion.setBounds(335, 188, 140, 38);
        btnLeccion.addActionListener(e -> mostrarPanel("Leccion"));
        panelUsuario.setLayout(null);
        panelUsuario.add(btnLeccion);

        // Botón para cerrar sesión
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.setBounds(335, 350, 140, 38);
        btnCerrarSesion.addActionListener(e -> {
            txtUsuario.setText("");
            txtPassword.setText("");
            mostrarPanel("Login");
        });
        panelUsuario.add(btnCerrarSesion);

        return panelUsuario;
    }

    /** Método para mostrar el panel con una imagen de ayuda */
    private void mostrarPanelConImagen() {
        // Cargar la imagen de ayuda
        ImageIcon imagen = new ImageIcon(".\\imagenes\\ayuda_dedos_mecano.png");
        JLabel imagenLabel = new JLabel(imagen);

        // Crear el texto de ayuda
        JLabel textoLabel = new JLabel("Coloca los dedos como en la imagen y úsalos con los colores");
        textoLabel.setForeground(Color.WHITE);
        textoLabel.setFont(new Font("Arial", Font.BOLD, 16));

        // Panel para mostrar la imagen y el texto
        JPanel panelImagenConTexto = new JPanel();
        panelImagenConTexto.setLayout(null);
        panelImagenConTexto.setPreferredSize(new Dimension(imagen.getIconWidth(), imagen.getIconHeight()));

        imagenLabel.setBounds(0, 0, imagen.getIconWidth(), imagen.getIconHeight());
        panelImagenConTexto.add(imagenLabel);
        textoLabel.setBounds(10, 10, 400, 30);
        panelImagenConTexto.add(textoLabel);

        // Mostrar el panel en un JOptionPane
        JOptionPane.showMessageDialog(this, panelImagenConTexto, "Ayuda", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Método para crear el panel de la lección */
    private JPanel crearPanelLeccion() {
        JPanel panel = new JPanel();

        JTextArea areaTexto = new JTextArea("Hola");
        areaTexto.setBounds(0, 0, 784, 22);
        areaTexto.setToolTipText("Hola");
        teclado = new TecladoVirtual();
        teclado.setBounds(0, 436, 784, 92);
        panel.setLayout(null);
        panel.add(areaTexto);
        panel.add(teclado);

        // Campo de texto para escribir
        JTextArea areaEscribir = new JTextArea();
        teclado.add(areaEscribir);
        areaEscribir.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                teclado.resaltarTecla(e.getKeyChar(), true);
            }
        });

        return panel;
    }

    /** Método para crear el panel de administración */
    private JPanel crearPanelAdmin() {
        JPanel panelAdministracion = new JPanel();

        // Cargar usuarios en la lista
        DefaultListModel<String> modeloLista = new DefaultListModel<>();
        Utilidades.cargarUsuarios().forEach(usuario -> modeloLista.addElement(usuario.getNombre()));
        panelAdministracion.setLayout(null);

        // Crear lista de usuarios
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(467, 0, 317, 493);
        panelAdministracion.add(scrollPane);
        JList<String> listaUsuarios = new JList<>(modeloLista);
        scrollPane.setViewportView(listaUsuarios);
        String usuarioSeleccionado = listaUsuarios.getSelectedValue();

        // Panel inferior con campos para crear o eliminar usuarios
        JPanel panelInferior = new JPanel();
        panelInferior.setBounds(0, 493, 784, 46);

        JTextField txtNuevoUsuario = new JTextField();
        txtNuevoUsuario.setBounds(261, 0, 261, 23);
        JTextField txtNuevoPassword = new JTextField();
        txtNuevoPassword.setBounds(0, 23, 261, 23);
        panelInferior.setLayout(null);

        JLabel label = new JLabel("Nuevo Usuario:");
        label.setBounds(0, 0, 261, 23);
        panelInferior.add(label);
        panelInferior.add(txtNuevoUsuario);
        JLabel label_1 = new JLabel("Contraseña:");
        label_1.setBounds(522, 0, 261, 23);
        panelInferior.add(label_1);
        panelInferior.add(txtNuevoPassword);

        // Botón para agregar usuario
        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(261, 23, 261, 23);
        btnAgregar.addActionListener(e -> {
            String nombre = txtNuevoUsuario.getText();
            String password = txtNuevoPassword.getText();

            if (!nombre.isEmpty() && !password.isEmpty()) {
                Utilidades.guardarUsuario(new Usuario(nombre, password));
                modeloLista.addElement(nombre);
                JOptionPane.showMessageDialog(this, "Usuario creado exitosamente");

                txtNuevoUsuario.setText("");
                txtNuevoPassword.setText("");
                mostrarPanel("Login");
            } else {
                JOptionPane.showMessageDialog(this, "Debe llenar todos los campos");
            }
        });
        panelInferior.add(btnAgregar);

        // Botón para eliminar usuario
        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(522, 23, 261, 23);
        btnEliminar.addActionListener(e -> {
            Utilidades.eliminarUsuario(usuarioSeleccionado);
            modeloLista.removeElement(usuarioSeleccionado);
        });
        panelInferior.add(btnEliminar);

        panelAdministracion.add(panelInferior);

        // Botón para cerrar sesión
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.setBounds(177, 222, 140, 38);
        btnCerrarSesion.addActionListener(e -> {
            txtUsuario.setText("");
            txtPassword.setText("");
            mostrarPanel("Login");
        });
        panelAdministracion.add(btnCerrarSesion);

        return panelAdministracion;
    }

    /** Inicia la carga del panel */
    private void iniciarCarga() {
        new Timer(6000, e -> {
            mostrarPanel("Login");
            ((Timer) e.getSource()).stop();
        }).start();
    }

    /** Método para validar las credenciales de login */
    private void validarCredenciales() {
        String usuario = txtUsuario.getText();
        String password = new String(txtPassword.getPassword());
        List<Usuario> usuarios = Utilidades.cargarUsuarios();

        // Comprobar si las credenciales son correctas
        if ("a".equals(usuario) && "a".equals(password)) {
            mostrarPanel("Admin");
        } else {
            for (Usuario u : usuarios) {
                if (u.getNombre().equals(usuario) && u.getContraseña().equals(password)) {
                    mostrarPanel("Menu");
                    return;
                }
            }
            JOptionPane.showMessageDialog(this, "Credenciales incorrectas");
        }
    }

    /** Método para mostrar un panel específico */
    private void mostrarPanel(String panel) {
        CardLayout cl = (CardLayout) getContentPane().getLayout();
        cl.show(getContentPane(), panel);
    }

    /** Método principal para ejecutar la aplicación */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new Main().setVisible(true));
    }
}

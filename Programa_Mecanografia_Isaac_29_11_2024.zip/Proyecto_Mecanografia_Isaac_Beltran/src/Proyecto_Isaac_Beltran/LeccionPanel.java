package Proyecto_Isaac_Beltran;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask;

public class LeccionPanel extends JPanel {
    private String dificultad;
    private JTextArea areaTexto;
    private JTextArea areaEscribir;
    private Timer timer;
    private int tiempoRestante;
    private int erroresCometidos;
    private JLabel labelTiempo, labelErrores;

    public LeccionPanel(String dificultad) {
        this.dificultad = dificultad;
        setLayout(null);

        // Crear la interfaz de la lección
        areaTexto = new JTextArea();
        areaTexto.setEditable(false);
        areaTexto.setBounds(20, 20, 740, 100);
        add(areaTexto);

        areaEscribir = new JTextArea();
        areaEscribir.setBounds(20, 140, 740, 100);
        areaEscribir.setLineWrap(true);
        areaEscribir.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                verificarError(e);
            }
        });
        add(areaEscribir);

        // Etiquetas de tiempo y errores
        labelTiempo = new JLabel("Tiempo: 00:00");
        labelTiempo.setBounds(20, 260, 100, 30);
        add(labelTiempo);

        labelErrores = new JLabel("Errores: 0");
        labelErrores.setBounds(140, 260, 100, 30);
        add(labelErrores);

        // Establecer el texto de la lección según la dificultad
        if ("Fácil".equals(dificultad)) {
            areaTexto.setText("Este es un texto de ejemplo pequeño para practicar mecanografía.");
            tiempoRestante = 240;  // 4 minutos
            erroresCometidos = 0;
        } else if ("Difícil".equals(dificultad)) {
            areaTexto.setText("Este es un texto de ejemplo más largo para un desafío más difícil con más caracteres.");
            tiempoRestante = 180;  // 3 minutos
            erroresCometidos = 0;
        }

        // Iniciar el temporizador
        iniciarTemporizador();
    }

    // Método para iniciar el temporizador de la lección
    private void iniciarTemporizador() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (tiempoRestante > 0) {
                    tiempoRestante--;
                    labelTiempo.setText("Tiempo: " + (tiempoRestante / 60) + ":" + (tiempoRestante % 60));
                } else {
                    // Si el tiempo se agota, finalizar la lección
                    JOptionPane.showMessageDialog(LeccionPanel.this, "Se acabó el tiempo. Has cometido " + erroresCometidos + " errores.");
                    timer.cancel();
                }
            }
        }, 0, 1000);
    }

    // Método para verificar errores cometidos por el usuario
    private void verificarError(KeyEvent e) {
        String textoCorrecto = areaTexto.getText();
        String textoUsuario = areaEscribir.getText();
        if (!textoUsuario.equals(textoCorrecto.substring(0, textoUsuario.length()))) {
            erroresCometidos++;
            labelErrores.setText("Errores: " + erroresCometidos);
        }

        if (erroresCometidos >= (dificultad.equals("Fácil") ? 5 : 3)) {
            JOptionPane.showMessageDialog(this, "Has alcanzado el límite de errores permitidos.");
            timer.cancel();
        }
    }
}

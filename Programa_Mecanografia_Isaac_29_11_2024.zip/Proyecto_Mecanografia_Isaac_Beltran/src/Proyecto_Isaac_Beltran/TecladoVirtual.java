package Proyecto_Isaac_Beltran;

import javax.swing.*;
import java.awt.*;

public class TecladoVirtual extends JPanel {
    private JButton[] teclas;

    /** Constructor del teclado virtual */
    public TecladoVirtual() {
        setLayout(new GridLayout(4, 10));  // Establece un diseño de cuadrícula 4x10 para las teclas
        String letras = "QWERTYUIOPASDFGHJKLÑZXCVBNM";  // Las letras a utilizar en el teclado
        teclas = new JButton[letras.length()];

        // Crear un botón para cada tecla
        for (int i = 0; i < letras.length(); i++) {
            teclas[i] = new JButton(String.valueOf(letras.charAt(i)));
            teclas[i].setFocusable(false);  // Las teclas no son enfocables (evitar que se resalten)
            add(teclas[i]);  // Añadir la tecla al panel
        }
    }

    /** Resalta la tecla presionada con un color verde (correcto) o rojo (incorrecto) */
    public void resaltarTecla(char letra, boolean correcta) {
        for (JButton tecla : teclas) {
            // Compara la letra de la tecla con la letra pasada como parámetro
            if (tecla.getText().equalsIgnoreCase(String.valueOf(letra))) {
                // Cambiar el color dependiendo de si la respuesta es correcta o no
                tecla.setBackground(correcta ? Color.GREEN : Color.RED);
                break;
            }
        }
    }
}

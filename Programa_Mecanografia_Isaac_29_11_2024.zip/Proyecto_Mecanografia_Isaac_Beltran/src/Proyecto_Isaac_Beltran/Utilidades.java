package Proyecto_Isaac_Beltran;

import java.io.*;
import java.util.*;

public class Utilidades {

    /** Carga los usuarios desde el archivo usuarios.txt */
    public static List<Usuario> cargarUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("usuarios.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");  // Separa el nombre y la contraseña
                if (partes.length == 2) {
                    usuarios.add(new Usuario(partes[0], partes[1]));  // Crear usuario y añadir a la lista
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar usuarios: " + e.getMessage());
        }
        return usuarios;
    }

    /** Guarda un nuevo usuario en el archivo usuarios.txt */
    public static void guardarUsuario(Usuario usuario) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("usuarios.txt", true))) {
            pw.println(usuario.getNombre() + "," + usuario.getContraseña());  // Escribe en el archivo
        } catch (IOException e) {
            System.out.println("Error al guardar usuario: " + e.getMessage());
        }
    }

    /** Elimina un usuario del archivo usuarios.txt */
    public static void eliminarUsuario(String nombre) {
        List<Usuario> usuarios = cargarUsuarios();  // Cargar todos los usuarios
        usuarios.removeIf(u -> u.getNombre().equals(nombre));  // Eliminar el usuario con el nombre especificado
        try (PrintWriter pw = new PrintWriter(new FileWriter("usuarios.txt"))) {
            for (Usuario u : usuarios) {
                pw.println(u.getNombre() + "," + u.getContraseña());  // Escribe los usuarios restantes en el archivo
            }
        } catch (IOException e) {
            System.out.println("Error al eliminar usuario: " + e.getMessage());
        }
    }
}

package Proyecto_Isaac_Beltran;

public class Usuario {
    
    // ATRIBUTOS
    private String nombre;
    private String contraseña;

    /** Constructor para crear un nuevo usuario */
    public Usuario(String nombre, String contraseña) {
        this.nombre = nombre;
        this.contraseña = contraseña;
    }

    // GETTERS Y SETTERS
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    // MÉTODOS
    /** Sobrescribe el método toString para mostrar la información del usuario */
    @Override
    public String toString() {
        return "Usuario [nombre=" + nombre + ", contraseña=" + contraseña + "]";
    }
}

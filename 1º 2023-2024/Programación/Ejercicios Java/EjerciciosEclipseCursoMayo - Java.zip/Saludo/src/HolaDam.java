
public class HolaDam {

	public static void main(String[] args) {
		// Saludo DAM
		
		// Declaración Variable
		// Tipo entero para la edad, tipo de dato
		int edad;
		//String tipo para cadena de caracteres
		String saludo;
		
		//Asignar valor
		// Se utiliza un = que será nombre de la variable = valor
		edad = 25;
		saludo = "Hola 1 de DAM";
		
		//Double para decimal
		//Declarar variable y asignar a la vez
		// area = 3.12
		double area = 3.12;
		// Se pueden declarar varias variables del mismo tipo a la vez
		int sumando1, sumando2;
		sumando1 = 82;
		sumando2 = 17;
		int suma = sumando1 + sumando2;
		int resta = sumando1 - sumando2;
		int división = sumando1 / sumando2;
		int multiplicación = sumando1 * sumando2;
		int porcentaje = sumando1 % sumando2;
		/*
		 * 
		 * 
		*/
		System.out.println(edad);
		System.out.println("Hola primero de DAM " + edad);
		System.out.println(saludo);
		System.out.println("La suma es " + suma);
		System.out.println("La resta es " + resta);
		System.out.println("La división es " + división);
		System.out.println("La multiplicación es " + multiplicación);
		System.out.println("El porcentaje es " + porcentaje);
		
		
	}

	
}



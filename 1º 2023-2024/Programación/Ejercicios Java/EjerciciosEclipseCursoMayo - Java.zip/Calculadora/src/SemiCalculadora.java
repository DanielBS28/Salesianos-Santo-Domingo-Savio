
public class SemiCalculadora {

	public static void main(String[] args) {
		int sumando1, sumando2;
		sumando1 = 82;
		sumando2 = 17;
		
		int suma = sumando1 + sumando2;
		int resta = sumando1 - sumando2;
		int división = sumando1 / sumando2;
		int multiplicación = sumando1 * sumando2;
		int porcentaje = sumando1 % sumando2;
		
		System.out.println("La suma es " + suma);
		System.out.println("La resta es " + resta);
		System.out.println("La división es " + división);
		System.out.println("La multiplicación es " + multiplicación);
		System.out.println("El porcentaje es " + porcentaje);
		

	}

}

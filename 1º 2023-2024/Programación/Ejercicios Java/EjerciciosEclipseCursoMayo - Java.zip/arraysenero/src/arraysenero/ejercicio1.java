package arraysenero;

public class ejercicio1 {

	public static void main(String[] args) {
	
	
	

	}

}

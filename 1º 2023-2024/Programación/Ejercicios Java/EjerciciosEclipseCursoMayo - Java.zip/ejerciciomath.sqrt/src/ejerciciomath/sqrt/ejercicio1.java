package ejerciciomath.sqrt;

import java.util.Scanner;

public class ejercicio1 {

	public static void main(String[] args) {
		
		//Calcular el area de un triangulo a partir de los 3 lados 
		
		double a,b,c,d;
		
		Scanner teclado = new Scanner (System.in);
		Math.sqrt(9);
	}
}

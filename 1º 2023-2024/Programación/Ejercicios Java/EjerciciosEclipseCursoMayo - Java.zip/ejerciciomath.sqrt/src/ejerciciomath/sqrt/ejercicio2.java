package ejerciciomath.sqrt;

public class ejercicio2 {

	public static void main(String[] args) {

		int numero = 725;

		System.out.println(numero / 100);
		System.out.println((numero - 700) / 10);
		System.out.println(numero - 720);

	}

}

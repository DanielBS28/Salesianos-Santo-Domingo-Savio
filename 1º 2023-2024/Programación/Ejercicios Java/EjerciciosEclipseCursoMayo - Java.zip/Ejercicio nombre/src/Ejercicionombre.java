
public class Ejercicionombre {

	public static void main(String[] args) {
	System.out.println("Daniel");
	System.out.println("Baldazo Sánchez");
	System.out.print("Nota de programación: ");
	System.out.println("8.75");
	System.out.print("Nota de base de datos: ");
	System.out.println("7.05");
	System.out.println("FINNN");

	}

}

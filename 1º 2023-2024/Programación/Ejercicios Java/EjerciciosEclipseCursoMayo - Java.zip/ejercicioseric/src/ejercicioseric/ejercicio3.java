package ejercicioseric;

public class ejercicio3 {

	public static void main(String[] args) {
		
		int num = 1;

		for (int i = 0; i<100 ; i++) {
			System.out.println(num);		
			num++;
		} 

	}

}

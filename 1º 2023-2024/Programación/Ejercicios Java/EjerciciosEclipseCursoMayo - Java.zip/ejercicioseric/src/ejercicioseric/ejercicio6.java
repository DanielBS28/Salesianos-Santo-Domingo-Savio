package ejercicioseric;

public class ejercicio6 {

	public static void main(String[] args) {
		
		int num = 100;

		for (int i = 100; i>0 ; i--) {
			System.out.println(num);		
			num--;
		} 

	}

}

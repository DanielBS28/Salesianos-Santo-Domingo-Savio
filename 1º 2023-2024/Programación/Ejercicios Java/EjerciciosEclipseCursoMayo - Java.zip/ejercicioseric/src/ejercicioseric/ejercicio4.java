package ejercicioseric;

public class ejercicio4 {

	public static void main(String[] args) {
		
		int num = 100;

		while (num > 0) {
			System.out.println(num);
			num--;
		}
	}
}
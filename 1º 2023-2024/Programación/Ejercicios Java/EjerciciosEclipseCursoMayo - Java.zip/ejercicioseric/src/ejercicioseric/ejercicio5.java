package ejercicioseric;

public class ejercicio5 {

	public static void main(String[] args) {
		
		int num = 100;

		do {
			System.out.println(num);
			num--;
		} while (num > 0);

	}

}

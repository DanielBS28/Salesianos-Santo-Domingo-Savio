package repasoexamenenero;

public class ejercicio1 {

	public static void main(String[] args) {
		
		/* int mesaño = 12;
		int dias;
		char letra;
		String palabra;
		
		System.out.println("Datos por pantalla " + mesaño + " Hola");
		*/
		final int divisor = 3; // Constante
		int i = 1;
		int suma = 0, multiplicación = 1, division =1;
		suma = suma + i; 
		System.out.println("Numero: "+ i +" Suma: " + suma + " Multiplicacion: " + multiplicación + " División: " + division);
		
		
		double numero = 1.0;
		
		int n1 = (int) numero;
		
		
	}

}

package repaso;

public class ejercicio {

	public static void main(String[] args) {
		double numero1 = 23;
		double numero2 = 12;
		double resultado = 0;
		resultado = (numero1 + numero2);
		System.out.println(resultado);
		resultado = ((resultado -10) * numero1);
		System.out.println(resultado);
		resultado = ((resultado/numero2)+20);
		System.out.println(resultado);
	}

}

package ejerciciodeprueba;

public class ejercicio1 {

	public static void main(String[] args) {
		String miFruta = "Naranja";
		
		if (miFruta.equals("Naranja")) {
			System.out.println("Iguales");
				
		}else 
			System.out.println("Diferentes");
	}

}

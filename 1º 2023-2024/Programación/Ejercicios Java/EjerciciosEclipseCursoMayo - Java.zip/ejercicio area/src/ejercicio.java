
public class ejercicio {

	public static void main(String[] args) {
		int lado = 7;
		
		int perimetro = lado * 4;
		
		double area = Math.pow(lado, 2); 
		
		System.out.println("El perímetro es " + perimetro);
		System.out.printf("El area es %.0f",area);

	}

}
